
        function selectMovie(movieId) {
            // Esconde os horários de todos os filmes
            const allHours = document.querySelectorAll('.horas');
            allHours.forEach(hours => hours.style.display = 'none');
    
            // Mostra os horários do filme selecionado
            const selectedHours = document.getElementById(`hours-${movieId}`);
            selectedHours.style.display = 'block';
        }
    
        function lugarSelecionado(movieId) {
            const seating = document.getElementById('seating');
            const seatsContainer = document.getElementById('seats');
            seating.style.display = 'flex';
        
            seatsContainer.innerHTML = '';
            const rows = ['A', 'B', 'C', 'D', 'E'];
        
            rows.forEach((row) => {
                const rowLabel = document.createElement('div');
                rowLabel.textContent = row;
                rowLabel.style.textAlign = 'center';
                seatsContainer.appendChild(rowLabel);
        
                for (let i = 1; i <= 6; i++) {
                    const seat = document.createElement('div');
                    seat.classList.add('seat');
                    seat.textContent = `${row}${i}`;
                    
            
        
                    if (Math.random() > 0.7 || (row === 'A' && i === 1) || (row === 'C' && i === 3)) {
                        seat.classList.add('occupied');
                    }
        
                    seat.onclick = function () {
                        if (!seat.classList.contains('occupied')) {
                            seat.classList.toggle('selected');
                        }
                    };
        
                    seatsContainer.appendChild(seat);
                }
            });
        }
        
        function reservarAssentos() {
            const selectedSeats = document.querySelectorAll('.seat.selected');
            selectedSeats.forEach((seat) => {
                seat.classList.remove('selected');
                seat.classList.add('occupied');
            });
            alert('Poltronas reservadas com sucesso!');
        }
        
        function selectMovie(movieId) {
            const allHours = document.querySelectorAll('.horas');
            allHours.forEach(hours => hours.style.display = 'none');
        
            const selectedHours = document.getElementById(`hours-${movieId}`);
            selectedHours.style.display = 'block';
        }
        
        function lugarSelecionado(movieId) {
            const seating = document.getElementById('seating');
            const seatsContainer = document.getElementById('seats');
            seating.style.display = 'flex';
        
            seatsContainer.innerHTML = '';
            const rows = ['A', 'B', 'C', 'D', 'E'];
        
            rows.forEach((row, rowIndex) => {
                const rowLabel = document.createElement('div');
                rowLabel.textContent = row;
                rowLabel.style.textAlign = 'center';
                seatsContainer.appendChild(rowLabel);
        
                for (let i = 1; i <= 6; i++) {
                    const seat = document.createElement('div');
                    seat.classList.add('seat');
                    seat.textContent = `${row}${i}`;
                    
                    if (Math.random() > 0.7 || (row === 'A' && i === 1) || (row === 'C' && i === 3)) {
                        seat.classList.add('occupied');
                    }
        
                    seat.onclick = function () {
                        if (!seat.classList.contains('occupied')) {
                            seat.classList.toggle('selected');
                        }
                    };
        
                    seatsContainer.appendChild(seat);
                    
                }
            });
        }

  
//bomboniere
const products = [
    { id: 'product1', name: 'Pipoca Grande', price: 32.00, image: "imagens/pipocaGrande.png"},
    { id: 'product2', name: 'Pipoca Média', price: 26.00, image:  "imagens/PipocaPequena.webp"},
    { id: 'product3', name: 'Pipoca Pequena', price: 26.00, image: "imagens/pipocaMedia.png."},
    { id: 'product4', name: 'Refrigerante 500ml', price: 18.00, image: "imagens/refri500.png.png" },
    { id: 'product5', name: 'Refrigerante 300ml', price: 12.50, image: "imagens/refri300.png.png"},
    { id: 'product6', name: 'Chocolates', price: 8.50, image: "imagens/chocolates.png" },
    { id: 'product7', name: 'Combo Pipoca Grande e Refri 500ml', price: 39.99, image: "imagens/combo1.png" },
    { id: 'product8', name: 'Balde de pipoca Deadpool e Wolverine', price: 49.99, image: "imagens/baldedead.png" },
    { id: 'product9', name: 'Meia Entrada', price: 14.00, image: "imagens/ticket.png" },
    { id: 'product10', name: 'Entrada Cheia', price: 28.00, image: "imagens/ticket.png" }
    
]



function loadProducts() {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    products.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('produto');
        productDiv.innerHTML = `
            <img class="doces" src="${product.image}" alt="${product.name}">
            <span class="nomeProduto">${product.name}</span>
            <div class="product-controls">
                <button onclick="decrementQuantity('${product.id}')">-</button>
                <input type="number" id="${product.id}" value="0" min="0" readonly>
                <button onclick="incrementQuantity('${product.id}')">+</button>
                <span>R$ ${product.price.toFixed(2)}</span>
            </div>
        `;
        productList.appendChild(productDiv);
    });

    const totalDiv = document.createElement('div');
    totalDiv.classList.add('total');
    totalDiv.id = 'total-display';
    totalDiv.textContent = `Total: R$ 0.00`;
    productList.appendChild(totalDiv);

    const pagarDiv = document.createElement('div');
    pagarDiv.classList.add('pagar');
    pagarDiv.innerHTML = `
        <button id="pagar-btn" onclick="pagar()">Pagar: R$ 0.00</button>
    `;
    productList.appendChild(pagarDiv);
}

function updateTotal() {
    let total = 0;
    products.forEach(product => {
        const quantity = parseInt(document.getElementById(product.id).value, 10);
        total += quantity * product.price;
    });
    document.getElementById('total-display').innerText = `Total: R$ ${total.toFixed(2)}`;
    document.getElementById('pagar-btn').innerText = `Pagar: R$ ${total.toFixed(2)}`;
}

function incrementQuantity(productId) {
    const input = document.getElementById(productId);
    input.value = parseInt(input.value, 10) + 1;
    updateTotal();
}

function decrementQuantity(productId) {
    const input = document.getElementById(productId);
    const currentValue = parseInt(input.value, 10);
    if (currentValue > 0) {
        input.value = currentValue - 1;
    }
    updateTotal();
}

function pagar() {
    alert('Compra realizada com sucesso :)');
}

loadProducts();
